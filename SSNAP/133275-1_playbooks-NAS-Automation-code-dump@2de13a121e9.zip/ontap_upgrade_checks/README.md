# ONTAP Upgrade Pre-checks

Ansible playbooks for ONTAP Upgrade Pre-checks for Deutsche Bank

# Prerequisites

* Python 3.7 & above
* Python netapp-lib modules
* Ansible 2.9 & above
* netapp.ontap ansible collections

# Authors & Contributors

* NetApp Global Services Solutions Center
* Madhu Marripelli (madhu.marripelli@netapp.com)
* Venu Kulala (venu.kulala@netapp.com)
* Durai Murugan Sakthivadivel (durai.sakthivadivel@netapp.com)