﻿param(
  [parameter(Mandatory=$True)]
  [string]$src_cluster_name,
  [parameter(Mandatory=$True)]
  [string]$src_svm_name,
  [parameter(Mandatory=$true)]
  [string]$service,
  [parameter(Mandatory=$True)]
  [string]$dest_svm_service_name,
  [parameter(Mandatory=$True)]
  [string]$environment,
  [parameter(Mandatory=$True)]
  [string]$RITM,
  [parameter(Mandatory=$True)]
  [string]$sys_id,
  [parameter(Mandatory=$True)]
  [string]$rest_host,
  [parameter(Mandatory=$True)]
  [string]$dest_svm_node,
  [parameter(Mandatory=$True)]
  [string]$dest_cluster_name,
  [parameter(Mandatory=$True)]
  [string]$dest_svm_name,
  [parameter(Mandatory=$False)]
  [string]$dest_data_ip_list,
  [parameter(Mandatory=$False)]
  [string]$dest_backup_ip_list,
  [parameter(Mandatory=$False)]
  [string]$dest_route_list,
  [parameter(Mandatory=$True)]
  [string]$snapmirror_policy,
  [parameter(Mandatory=$True)]
  [string]$is_geo_vlan
)

########################################################################
# FUNCTIONS
########################################################################
#-----------------------------------------------------------------------
# UTILITY FUNCTIONS
#-----------------------------------------------------------------------
function Get-WFAUserPassword () {
   param(
      [parameter(Mandatory=$true)]
      [string]$pw2get
   )

   $InstallDir = (Get-ItemProperty -Path HKLM:\Software\NetApp\WFA -Name WFAInstallDir).WFAInstallDir
  
   $string = Get-Content $InstallDir\jboss\bin\wfa.conf | Where-Object { $_.Contains($pw2get) }
   $mysplit = $string.split(":")
   $var = $mysplit[1]
  
   cd $InstallDir\bin\supportfiles\
   $string = echo $var | .\openssl.exe enc -aes-256-cbc -pbkdf2 -iter 100000 -a  -d -salt -pass pass:netapp

   return $string
  }

function submit_request() {
  param(
    [parameter(Mandatory=$True)]
    [hashtable]$raw_service_request,
    [parameter(Mandatory=$True)]
    [hashtable]$rest_cfg
  )

  #--------------------------------------------------------
  # REST API call to submit the request
  #--------------------------------------------------------
  [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true} ;
  $result = Invoke-WebRequest -uri $($rest_cfg['host'] + '/api/v1/nas_provisioning/svm')`
            -Method POST `
            -body $( ConvertTo-Json @{"raw_service_request" = $raw_service_request} -Depth 10 )  `
            -Headers @{ "Content-Type" = "application/json" }
  if ( $result.StatusCode -ne 201 ){
    Get-WfaLogger -Info -Message "Status code not 201"
    Get-WfaLogger -Info -Message $($result.StatusDescription)
    Throw $result.StatusDescription
  }
  Get-WfaLogger -Info -Message "Request successfully submitted"
}

function ontap_svm_dr(){
  param(
    [parameter(Mandatory=$true)]
    [hashtable]$request,
    [parameter(Mandatory=$True)]
    [string]$mysql_pw
  )

  #------------------------------------------------------------------
  # Define the return value
  #------------------------------------------------------------------
  $return_ontap_svm_dr = @{
    'success'           = $true;
    'reason'            = "Success";
    'ontap_svm_dr'     = @()
  }
  $tmp = @{
      'src_cluster'           = $request['src_cluster_name'].split(".")[0];
      'src_svm'               = $request['src_svm_name'];
      'dest_cluster'          = $request['dest_cluster_name'].split(".")[0];
      'dest_svm'              = $request['dest_svm_name'];
      'hostname'              = $request['dest_cluster_name'];
      'identity_preserve'     = 'true';
      'relationship_type'     = 'data_protection';
      'schedule'              = 'snapmirror_15min';
      'policy'                = $request['snapmirror_policy'];

  }

  $return_ontap_svm_dr['ontap_svm_dr'] += $tmp
  
  return $return_ontap_svm_dr
}

function schedule() {
  param(
     [parameter(Mandatory=$true)]
     [hashtable]$request,
     [parameter(Mandatory=$true)]
     [string]$mysql_pw
  )

  $ontap_schedule = @{
    'success'       = $True;
    'reason'        = 'success';
    'ontap_schedule'  = @();
  }

    $new_cfg = @{
      'hostname'      = $request['dest_cluster_name'];
      'name'          = 'snapmirror_15min';
      'minutes'       = '15'
      'hours'         = '-1'
      }

    $ontap_schedule['ontap_schedule'] += $new_cfg

  return $ontap_schedule

}

function ontap_net_interface() {
  param(
     [parameter(Mandatory=$true)]
     [hashtable]$request,
     [parameter(Mandatory=$True)]
     [string]$mysql_pw
  )

  $ontap_interface = @{
    'success'       = $True;
    'reason'        = "success";
    'ontap_net_interface' = @()
  }

  $sql = "
    SELECT *
    FROM db_cfg.svm_interface
    WHERE 1 = 1
      AND service = '" + $request['service'] + "'
      AND service_name  = '" + $request['service_name'] + "'
      AND environment = '" + $request['environment'] + "'
      AND model = '" + $request['dest_svm_node_model'] + "'
    ;
  "
  $interface_cfg = Invoke-MySqlQuery -query $sql -user root -password $mysql_pw
  get-wfalogger -info -message $sql
  #------------------------------------------------------------------
  # We assume that all node names end in 'n[0-9]+$'.  The node name
  # in the table is of the form %cluster%n[0-9]+$, so we can just
  # take the node name out of the table, do a substitution on
  # %cluster% and have our node name.
  #------------------------------------------------------------------
  if ( $interface_cfg[0] -eq 0 ){
    return $ontap_interface
  }
  get-wfalogger -info -message $('data ip count= ' +$request['dest_data_ip_list'].Count)
  get-wfalogger -info -message $('backup ip count= ' +$request['dest_bkup_ip_list'].Count)
  $data_ip_idx = 0
  $bkup_ip_idx = 0
  foreach ( $lif_def in $interface_cfg[ 1 .. $interface_cfg[0] ] ){
    get-wfalogger -info -message $($lif_def | Out-String)
    $lif_name_pattern = $lif_def['name_pattern'] -replace '%svm%', $request['dest_svm_name']
    get-wfalogger -info -message $($lif_name_pattern)
    if( $lif_def['name_pattern'] -match 'bkup' ){
      $ip = $request['dest_bkup_ip_list'][$bkup_ip_idx]
      $lif_name = $lif_name_pattern -replace '#', $( $bkup_ip_idx + 1 )
      $bkup_ip_idx += 1
    }
    else{      
      $ip = $request['dest_data_ip_list'][$data_ip_idx]
      $lif_name = $lif_name_pattern -replace '#', $( $data_ip_idx + 1 )
      $data_ip_idx += 1
    }
    get-wfalogger -info -message $('Lif name= ' + $lif_name)
    get-wfalogger -info -message $($ip | Out-String)
    $lif = @{
      'hostname'        = $request['dest_cluster_name'];
      'vserver'         = $request['dest_svm_name'];
      'interface_name'  = $lif_name;
      'home_node'       = $request['dest_svm_node'];
      'home_port'       = $lif_def['home_port'];
      'failover_group'  = $lif_def['failover_group'];
      'failover_policy' = $lif_def['failover_policy'];
      'address'         = $ip['addr'];
      'netmask'         = $ip['netmask'];
      'protocols'       = $lif_def['protocols'];
      'role'            = $lif_def['role'];
    }
    $ontap_interface['ontap_net_interface']  += $lif
  }

  return $ontap_interface
}

function ontap_net_route() {
  param(
     [parameter(Mandatory=$true)]
     [hashtable]$request,
     [parameter(Mandatory=$True)]
     [string]$mysql_pw
  )

  $ontap_net_route = @{
    'success'       = $True;
    'reason'        = "success";
    'ontap_net_route' = @()
  }

  foreach ( $route in $request['dest_routes'] ){
    $tmp = @{
      'hostname'        = $request['dest_cluster_name'];
      'vserver'         = $request['dest_svm_name'];
      'destination'     = $route['destination'];
      'gateway'         = $route['gateway'];
    }

    $ontap_net_route['ontap_net_route'] += $tmp
  }
  return $ontap_net_route
}

function servicenow(){
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request
   )
   $return_values = @()
   Get-WfaLogger -Info -Message $( "ServieNow Request Inputs " + $request)

   $comment = "SVM DR configuration has been completed for: " + $request['svm_name']

   $snow = @{
      'success'         = $True;
      'reason'          = "Connecting to ServiceNow";
      'servicenow'   = @(
        @{
          'comment'         = $comment;
          'correlation_id'  = $request['correlation_id'];
          'action'          = 'completed';
          'sys_id'          = $request['snow_request_id'];
        },
        @{
          'correlation_id'  = $request['correlation_id'];
          'action'          = 'logging';
          'sys_id'          = $request['snow_request_id'];
        }
      )
   }   
   return $snow
}


#--------- MAIN ---------------

$request = @{
  'src_cluster_name'            = $src_cluster_name;
  'dest_cluster_name'           = $dest_cluster_name;
  'snow_request_id'             = $sys_id;
  'correlation_id'              = $RITM;
  'src_svm_name'                = $src_svm_name;
  'dest_svm_name'               = $dest_svm_name;
  'dest_svm_node'               = $dest_svm_node;
  'service'                     = $service;
  'service_name'                = $dest_svm_service_name;
  'environment'                 = $environment;
  'snapmirror_policy'           = $snapmirror_policy
  'dest_data_ip_list'           = @();
  'dest_bkup_ip_list'           = @();
  'dest_routes'                 = @();

}

$raw_service_request = @{
  'service'     = 'svm_build';
  'operation'   = 'create';
  'std_name'    = 'none';
  'req_details' = @{}
}

$mysql_pw = Get-WFAUserPassword -pw2get 'MySQL'

Get-Wfalogger -Info -Message $(-not $is_geo_vlan)

if($is_geo_vlan -eq 'false'){

Get-Wfalogger -Info -Message "getting Data IP"
foreach( $ip_row in $dest_data_ip_list.Split(',') ){
  $addr, $netmask = $ip_row.Split('~')
  Get-Wfalogger -Info -Message $('addr= ' + $addr)
  $lif = @{
    "addr"    = $addr;
    "netmask" = $netmask;
  }
  $request['dest_data_ip_list'] += $lif
}

Get-Wfalogger -Info -Message "getting Bkp IP"
foreach( $ip_row in $dest_backup_ip_list.Split(',') ){
  $addr, $netmask = $ip_row.Split('~')
  Get-Wfalogger -Info -Message $('addr= ' + $addr)
  $lif = @{
    "addr"    = $addr;
    "netmask" = $netmask;
  }
  $request['dest_bkup_ip_list'] += $lif
}

Get-Wfalogger -Info -Message "getting network routes"
foreach( $ip_row in $dest_route_list.Split(',') ){
  $dest, $gw = $ip_row.Split('~')
  Get-Wfalogger -Info -Message $('gateway= ' + $addr)
  $route = @{
    "destination"    = $dest;
    "gateway"       = $gw;
  }
  $request['dest_routes'] += $route
}

$sql = "
    SELECT model
    FROM cm_storage.node
    WHERE 1 = 1
      AND node.name = '" + $request['dest_svm_node'] + "'
    ;
  "
  $model_query = Invoke-MySqlQuery -query $sql -user root -password $mysql_pw
  get-wfalogger -info -message $($model_query[1].model)
  $request['dest_svm_node_model'] = $($model_query[1].model)

Get-WfaLogger -Info -Message "##################### ONTAP_NET_INTERFACE #####################"
$ontap_net_interface = ontap_net_interface          `
              -request      $request      `
              -mysql_pw     $mysql_pw
if( -not $ontap_net_interface['success'] ){
  $fail_msg = $ontap_net_interface['reason']
  Get-WfaLogger -Info -Message $fail_msg
  Throw $fail_msg
}

$raw_service_request['req_details']['ontap_dest_net_interface'] = $ontap_net_interface['ontap_net_interface']
Get-WfaLogger -Info -Message $(ConvertTo-Json $raw_service_request -Depth 10)

if(-not ($request['dest_routes']['destination'] -eq "")){
Get-WfaLogger -Info -Message "##################### NET ROUTE #####################"
$ontap_net_route = ontap_net_route  `
              -request      $request `
              -mysql_pw     $mysql_pw
if( -not $ontap_net_route['success'] ){
  $fail_msg = $ontap_net_route['reason']
  Get-WfaLogger -Info -Message $fail_msg
  Throw $fail_msg
}

$raw_service_request['req_details']['ontap_dest_net_route'] = $ontap_net_route['ontap_net_route']
Get-WfaLogger -Info -Message $raw_service_request
}

}


Get-WfaLogger -Info -Message "##################### SVM DR Schedule #####################"
$ontap_schedule = schedule  `
              -request $request `
              -mysql_pw $mysql_pw
if( -not $ontap_schedule['success'] ){
  $fail_msg = $ontap_schedule['reason']
  Get-WfaLogger -Info -Message $fail_msg
  Throw $fail_msg
}
$raw_service_request['req_details']['ontap_schedule'] = $ontap_schedule['ontap_schedule']


Get-WfaLogger -Info -Message "##################### SVM DR CFG #####################"
$ontap_snapmirror = ontap_svm_dr      `
    -request    $request    `
    -mysql_pw   $mysql_pw
if ( -not $ontap_snapmirror['success'] ){
  $fail_msg = $ontap_snapmirror['reason']
  Get-WfaLogger -Info -Message $fail_msg
  Throw $fail_msg
}
$raw_service_request['req_details']['ontap_snapmirrorr'] = $ontap_snapmirror['ontap_svm_dr']

Get-WfaLogger -Info -Message "##################### SERVICENOW #####################"
$servicenow = servicenow  `
              -request $request 
if( -not $servicenow['success'] ){
  $fail_msg = $servicenow['reason']
  Get-WfaLogger -Info -Message $fail_msg
  Throw $fail_msg
}

$raw_service_request['req_details']['servicenow'] = $servicenow['servicenow']
Get-WfaLogger -Info -Message $(ConvertTo-Json $raw_service_request -Depth 10)

#$rest_cfg = @{'uri' = 'http://loninstorpc.uk.db.com:5001/api/v1/nas_provisioning/svm'}
#submit_request -raw_service_request $raw_service_request -rest_cfg $rest_cfg