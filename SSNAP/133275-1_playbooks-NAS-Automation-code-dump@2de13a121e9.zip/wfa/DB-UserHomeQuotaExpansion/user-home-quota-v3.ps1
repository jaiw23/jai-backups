﻿param(
       [parameter(Mandatory=$true)]
       [string]$setting,
       [parameter(Mandatory=$true)]
       [string]$user_id,
       [parameter(Mandatory=$false)]
       [string]$increment_mb,
       [parameter(Mandatory=$false)]
       [string]$task_id
    )

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
public bool CheckValidationResult(
ServicePoint srvPoint, X509Certificate certificate,
WebRequest request, int certificateProblem) {
return true;
}
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

Function Get-MySQLRootPW { 
   
   $REGISTRY      = "HKLM:\SOFTWARE\Wow6432Node\Apache Software Foundation\Procrun 2.0\NA_WFA_SRV\Parameters\Java"
   $httpPort      = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dhttp.port"}).split("=")[1]
   $httpsPort     = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dhttps.port"}).split("=")[1]
   $sql_root_pw   = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dmysql.password"}).split("=")[1]

   return $sql_root_pw;
}
 

Function MySQL {
    Param(
    [Parameter(
    Mandatory = $true,
    ParameterSetName = '',
    ValueFromPipeline = $true)]
    [string]$Query
    )
    $MySQLUser = "root"
    $Password = Get-MySQLRootPW
    $MySQLDB = "netapp_model_view"
    $MySQLHost = "nycinnwfap1.us.db.com"
    $ConnectionString = "server=" + $MySQLHost + ";port=3306;Integrated Security=False;uid=hc;pwd=Password20!!;database="+$MySQLDB
    Try {
        [void][System.Reflection.Assembly]::LoadFrom('C:\Program Files (x86)\MySQL\MySQL Installer for Windows\MySql.Data.dll')
        $Connection = New-Object MySql.Data.MySqlClient.MySqlConnection
        $Connection.ConnectionString = $ConnectionString
        $Connection.Open()
              if ($Connection.State -ne "Open") {
                     Start-Sleep -Seconds 10
                     $Connection.Open()
              }
        $Command = New-Object MySql.Data.MySqlClient.MySqlCommand($Query, $Connection)
        $DataAdapter = New-Object MySql.Data.MySqlClient.MySqlDataAdapter($Command)
        $DataSet = New-Object System.Data.DataSet
        $RecordCount = $DataAdapter.Fill($DataSet, "data")
        $DataSet.Tables[0]
    }

    Catch {
              get-wfalogger -info -message $($Error[0] | out-string)
    }

    Finally {
        $Connection.Close()
    }
}

Function FetchQuota {
    Param(
    [Parameter(Mandatory = $true)]
    [string]$userId
    )

$userQuotaDetails = @()
$userid = "DBG\\$userId"
$Query1 = "select user_quota.users as user,cast(user_quota.diskLimit/1024 as DECIMAL(6,0)) as diskLimitMB,cast(user_quota.diskUsed/1024 as DECIMAL(6,0)) as diskUsedMB,user_quota.quotaTarget,cluster.managementIp as cluster,vserver.name as vserver,volume.name as volume,qtree.name as qtree from user_quota join cluster on user_quota.clusterId = cluster.objid Join vserver on vserver.objid = user_quota.vserverId join volume on volume.objid = user_quota.volumeId join qtree on qtree.objid = user_quota.qtreeId where vserver.name not like '%dr' and qtree.name != '' and users = '$($userid)';"
$Query2 = "select user_quota.users as user,user_quota.diskLimit as diskLimitKB,user_quota.diskUsed as diskUsedKB,user_quota.quotaTarget,cluster.managementIp as cluster,vserver.name as vserver,volume.name as volume,qtree.name as qtree from user_quota join cluster on user_quota.clusterId = cluster.objid Join vserver on vserver.objid = user_quota.vserverId join volume on volume.objid = user_quota.volumeId join qtree on qtree.objid = user_quota.qtreeId where vserver.name not like '%dr' and qtree.name != '' and users = '$($userid)';"
#$query
$quota = MySQL -Query $Query1
Get-Wfalogger -info -message "`n`nH: drive path : $user_home_dfs_path`n`n"
Get-Wfalogger -info -message "Original Quota details: `n$($quota | Out-String)"
$quota = MySQL -Query $Query2
return $quota
}

function UpdateQuota() {
   param(
      [parameter(Mandatory=$true, HelpMessage="placement solution")]
      $userQuotaDetails,
      [parameter(Mandatory=$true, HelpMessage="placement solution")]
      [int]$increment_mb
   )
   
   $new_quota = [math]::Round($increment_mb*1024*1024) + $([int]$($userQuotaDetails.diskLimitKB)*1024)
   get-wfalogger -info -message $($new_quota)

   Try{
       Connect-WfaCluster $userQuotaDetails.cluster
       Set-NcQuota -Type user -Volume $userQuotaDetails.volume -Qtree $userQuotaDetails.qtree -VserverContext $userQuotaDetails.vserver -Target $userQuotaDetails.user -DiskLimit $new_quota
       start-ncquotaresize -volume $userQuotaDetails.volume -VserverContext $userQuotaDetails.vserver
       }
   Catch {
              get-wfalogger -info -message $($Error[0] | out-string)
   }

   Finally {
        $message = "Quota expanded for user : DBG\$user_id.`nOld quota = $([math]::Round([int]$($userQuotaDetails.diskLimitKB/1024))) MB,`nNew quota = $([math]::Round($new_quota/1024/1024)) MB, `nH: drive path = $user_home_dfs_path."
        Get-Wfalogger -info -message $message
        snow_comment -snow_cfg $snow_cfg -comment $message
   }

}

function snow_get_sysid() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$snow_cfg
   )
   #-----------------------------------------------------------------
   # FIXME: RTU 25 Oct 2021
   # NETAPP-81
   # We will now support snow updates from WFA
   # This function will get auth info and perform updates to snow
   #----------------------------------------------------------------- 
    try {
      $uri = "$($snow_cfg['base_url'])?sysparm_query=number=$($snow_cfg['task'])"
      $response = Invoke-WebRequest -uri $uri -Method GET `
         -body $( ConvertTo-Json $data -Depth 10 ) `
         -headers $snow_cfg['headers'] `
         -Proxy $snow_cfg['proxy']
      if ($response.StatusCode -ne 200){
         Get-Wfalogger -Info -Message  $("Error getting sys_id: $($_.Exception | out-String)")
         Throw "Invalid ITASK provided"
      }
      return $response
   }
   catch { Get-Wfalogger -Info -Message $($_ | Out-String)
           Throw "Cant get sys_id for $($snow_cfg['itask'])"
   }
}

function snow_comment() {
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$snow_cfg,
      [parameter(Mandatory=$true)]
      [string]$comment
   )
   #-----------------------------------------------------------------
   # FIXME: RTU 25 Oct 2021
   # NETAPP-81
   # We will now support snow updates from WFA
   # This function will get auth info and perform updates to snow
   #----------------------------------------------------------------- 

   $data = @{"work_notes" = $comment;"comments" = $comment}

    try {
      $uri = "$($snow_cfg['base_url'])/$($snow_cfg['sys_id'])"
      $response = Invoke-WebRequest -uri $uri -Method PUT `
         -body $( ConvertTo-Json $data -Depth 10 ) `
         -headers $snow_cfg['headers'] `
         -Proxy $snow_cfg['proxy']
      if ($response.StatusCode -ne 200){
         Get-Wfalogger -Info -Message $("Error commenting : $($_.Exception | out-String)")
      }
   }
   catch { Get-Wfalogger -Info -Message $($_ | Out-String)}
}

#------ SNOW variables ---------

$snow_cfg = @{
   'base_url'              = "https://dbunityworker.service-now.com/api/now/table/sc_task";
   'task'                  = $task_id;
   'proxy'                 = 'http://serverproxy.intranet.db.com:8080';
   "headers" = @{
                           "Content-Type" = "application/json";
                           "Authorization" = "Basic bmFzX2F1dG9tYXRpb25faW50ZXJmYWNlOk5mMkoxeE1N"};
    }


#------- MAIN ---------------

Get-Wfalogger -Info -Message "Selected $setting"

$user_home_dfs_path = (Get-ADUser -Identity $user_id -Properties HomeDirectory | Select HomeDirectory).HomeDirectory

switch($setting.ToLower())
{
    get-quota {
        $quota_details = FetchQuota -userId $user_id
        $count = ($quota_details | Measure-Object).Count
        if($count -eq 0){ Get-WFAlogger -info -message "Quota not enabled for user : $user_id. Please enable quota on volume and retry !"}
    }

    set-quota {
        $response_api = snow_get_sysid -snow_cfg $snow_cfg
        $snow_cfg['sys_id'] = ($response_api.content | convertfrom-json).result.sys_id
        $quota_details = FetchQuota -userId $user_id
        $count = ($quota_details | Measure-Object).Count
        if($count -eq 0){ Get-WFAlogger -info -message "Quota not enabled for user : $user_id. Please enable quota on volume and retry !"}
        elseif($count -eq 1){
        UpdateQuota -userQuotaDetails $quota_details -increment_mb $increment_mb
        }
        else {Get-WFAlogger -info -message "More than one user quota found for user : $user_id `n $($quota_details | Out-String)"}
    }

}
