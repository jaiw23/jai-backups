﻿param (
   [parameter(Mandatory=$False, HelpMessage="Application short name")]
   [string]$request_type,
  
   [parameter(Mandatory=$True, HelpMessage="email address")]
   [string]$email_address,

   [parameter(Mandatory=$True, HelpMessage="environment")]
   [string]$environment,
  
   [parameter(Mandatory=$True, HelpMessage="Desired storage location")]
   [string]$location,

   [parameter(Mandatory=$True, HelpMessage="Date Range")]
   [string]$date_range

)


function Get-WFAUserPassword () {
   param(
      [parameter(Mandatory=$true)]
      [string]$pw2get
   )

   $InstallDir = (Get-ItemProperty -Path HKLM:\Software\NetApp\WFA -Name WFAInstallDir).WFAInstallDir
   
   $string = Get-Content $InstallDir\jboss\bin\wfa.conf | Where-Object { $_.Contains($pw2get) }
   $mysplit = $string.split(":")
   $var = $mysplit[1]
   
   cd $InstallDir\bin\supportfiles\
   $string = echo $var | .\openssl.exe enc -aes-256-cbc -pbkdf2 -iter 100000 -a  -d -salt -pass pass:netapp
  
   return $string
  }


function budget_report(){
   param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [string]$db_user,
      [parameter(Mandatory=$true)]
      [string]$db_pw
   )
   Get-WfaLogger -Info -Message "Entered budget_report()"

   $budget_report_path = "$report_path/$($request['request_type'])-$wfa_job_id-$date_now.csv"

   $sql = "
         (SELECT 'Service','Budget_RITM','Environment','Location','Approved_Budget(GB)','Actual_Budget(GB)','Server_count_remaining','Refresh_Timestamp')
         UNION
         (SELECT service,ritm,env,location,approved_limit,budget,count,timestamp
         FROM playground.secops_budget where $($budget_environment_filter)
         AND $($budget_location_filter)
         INTO OUTFILE '$budget_report_path'
         FIELDS ENCLOSED BY '`"'
         TERMINATED BY ','
         ESCAPED BY '`"'
         LINES TERMINATED BY '\n')
         ;
      "
      Get-WfaLogger -Info -Message $sql
      $entries = Invoke-MySqlQuery -query $sql -user $db_user -password $db_pw
      Get-WfaLogger -Info -Message $($entries | Out-String)

      if( Test-Path $budget_report_path ){
      return $budget_report_path }
}

function allocation_report(){

param(
      [parameter(Mandatory=$true)]
      [hashtable]$request,
      [parameter(Mandatory=$true)]
      [string]$db_user,
      [parameter(Mandatory=$true)]
      [string]$db_pw
   )

   Get-WfaLogger -Info -Message "Entered chargeback_report()"

   $chargeback_report_path = "$report_path/$($request['request_type'])-$wfa_job_id-$date_now.csv"

   $sql = "
         (SELECT 'cluster_name','vserver_name','volume_name','qtree_name','cost_centre','protocol','storage_requirement_gb','nar_id','app_short_name','service_name','timestamp','environment','ritm')
         UNION
         (SELECT cluster_name,vserver_name,volume_name,qtree_name,cost_centre,protocol,storage_requirement_gb,nar_id,app_short_name,service_name,timestamp,environment,ritm
         FROM playground.chargeback where $($allocation_environment_filter)
         AND $($allocation_location_filter)
         AND service_name = 'secops'
         AND timestamp between '$($start_date)' and '$($end_date) 23:59:59.999'
         INTO OUTFILE '$chargeback_report_path'
         FIELDS ENCLOSED BY '`"'
         TERMINATED BY ','
         ESCAPED BY '`"'
         LINES TERMINATED BY '\n')
         ;
      "
      Get-WfaLogger -Info -Message $sql
      $entries = Invoke-MySqlQuery -query $sql -user $db_user -password $db_pw
      Get-WfaLogger -Info -Message $($entries | Out-String)
      
      if( Test-Path $chargeback_report_path ){
      return $chargeback_report_path }    
   
}

function send_email(){

param(
      [parameter(Mandatory=$true)]
      [string]$message,
      [parameter(Mandatory=$true)]
      [string]$report_path
   )

$email_obj = "D:\email_objects"


$email_body = '<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40"><head>
<meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
<meta name="Generator" content="Microsoft Word 15 (filtered medium)">
<!--[if !mso]><style>v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style><![endif]--><style><!--
/* Font Definitions */
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
/* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-fareast-language:EN-US;}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:#0563C1;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:#954F72;
	text-decoration:underline;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-priority:34;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-fareast-language:EN-US;}
span.EmailStyle18
	{mso-style-type:personal-compose;
	font-family:"Calibri",sans-serif;
	color:windowtext;}
span.EmailStyle20
	{mso-style-type:personal;
	font-family:"Calibri",sans-serif;
	color:windowtext;}
.MsoChpDefault
	{mso-style-type:export-only;
	font-size:10.0pt;
	font-family:"Calibri",sans-serif;
	mso-fareast-language:EN-US;}
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:72.0pt 72.0pt 72.0pt 72.0pt;}
div.WordSection1
	{page:WordSection1;}
--></style><!--[if gte mso 9]><xml>
<o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
<o:shapelayout v:ext="edit">
<o:idmap v:ext="edit" data="1" />
</o:shapelayout></xml><![endif]-->
</head>
<body lang="EN-GB" link="#0563C1" vlink="#954F72">
<table class="MsoTableGrid" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:none">
<tbody>
<tr style="height:40.85pt">
<td width="708" colspan="2" style="width:575.3pt;padding:0cm 0cm 0cm 0cm;height:40.85pt">
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><img width="314" height="58" id="Picture_x0020_4" src="cid:banner.png"><o:p></o:p></span></p>
</td>
</tr>
<tr style="height:55.75pt">
<td width="524" style="width:432.35pt;background:#9CC2E5;padding:0cm 0cm 0cm 0cm;height:55.75pt">
<p class="MsoNormal" align="center" style="text-align:center"><span style="font-size:20.0pt;color:white;mso-fareast-language:EN-GB">NetApp Managed Services Notification<o:p></o:p></span></p>
</td>
<td width="184" valign="top" style="width:142.95pt;background:white;padding:0cm 0cm 0cm 0cm;height:55.75pt">
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><img width="140" height="76" id="Picture_x0020_8" src="cid:pic.jpg"><o:p></o:p></span></p>
</td>
</tr>
<tr>
<td width="524" valign="top" style="width:432.35pt;padding:0cm 0cm 0cm 0cm">
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><o:p>&nbsp;</o:p></span></p>
</td>
<td style="border:none;padding:0cm 0cm 0cm 0cm" width="191">
<p class="MsoNormal">&nbsp;</p>
</td>
</tr>
<tr style="height:45.0pt">
<td width="524" valign="top" style="width:432.35pt;padding:0cm 0cm 0cm 0cm;height:45.0pt">
<p class="MsoNormal"><span style="font-size:16.0pt">Secops Report<o:p></o:p></span></p>
<p class="MsoNormal"><span style="font-size:16.0pt"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="font-size:14.0pt">'+ $message +'<o:p></o:p></span></p>
<p class="MsoNormal"><span style="font-size:16.0pt"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="font-size:16.0pt"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="font-size:16.0pt"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB">For any questions or concerns regarding this communication please contact NetApp Managed Services<o:p></o:p></span></p>
</td>
<td style="border:none;padding:0cm 0cm 0cm 0cm" width="191">
<p class="MsoNormal">&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB">Group email: </span>
<a href="mailto:db.global.netapp@list.db.com"><span style="mso-fareast-language:EN-GB">db.global.netapp@list.db.com</span></a><span style="color:#4472C4;mso-fareast-language:EN-GB"><o:p></o:p></span></p>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB">MyDB page: </span><a href="https://mydb.intranet.db.com/groups/netapp-managed-services"><span style="mso-fareast-language:EN-GB">https://mydb.intranet.db.com/groups/netapp-managed-services</span></a><span style="mso-fareast-language:EN-GB"><o:p></o:p></span></p>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><o:p>&nbsp;</o:p></span></p>
<p class="MsoNormal"><span style="mso-fareast-language:EN-GB"><img border="0" width="176" height="32" id="Picture_x0020_1" src="cid:netapp.png" alt="netapp 2 - Copy"><o:p></o:p></span></p>
<p class="MsoNormal"><o:p>&nbsp;</o:p></p>
</div>
</font></div>
</body>
</html>
'

    try{
	    $smtpServer = "smtphub.uk.mail.db.com"  
	    $msg = new-object Net.Mail.MailMessage  
	    $smtp = new-object Net.Mail.SmtpClient($smtpServer)  
	  
	    $msg.From = "db.global.netapp@list.db.com" 
	    $msg.To.Add("$email_address")
        $msg.Cc.Add("jai.waghela@db.com")
	    $msg.subject = "$wfa_job_id : SECOPS Reporting"  
	  
	    $msg.IsBodyHtml = $True  
	  
	    $msg.Body = $email_body
	  
	    $attachment = New-Object System.Net.Mail.Attachment –ArgumentList "$email_obj\banner.png"
	    $attachment.ContentDisposition.Inline = $True  
	    $attachment.ContentDisposition.DispositionType = "Inline"  
	    $attachment.ContentType.MediaType = "image/png"  
	    $attachment.ContentId = 'banner.png'  
	    $msg.Attachments.Add($attachment)  
	  
	    $attachment = New-Object System.Net.Mail.Attachment –ArgumentList "$email_obj\pic.jpg"
	    $attachment.ContentDisposition.Inline = $True  
	    $attachment.ContentDisposition.DispositionType = "Inline"  
	    $attachment.ContentType.MediaType = "image/jpg"  
	    $attachment.ContentId = 'pic.png'  
	    $msg.Attachments.Add($attachment)  
	  
	    $attachment = New-Object System.Net.Mail.Attachment –ArgumentList "$email_obj\netapp.png" 
	    $attachment.ContentDisposition.Inline = $True  
	    $attachment.ContentDisposition.DispositionType = "Inline"  
	    $attachment.ContentType.MediaType = "image/png"  
	    $attachment.ContentId = 'netapp.jpg'  
	    $msg.Attachments.Add($attachment) 

        $attachment1 = New-Object System.Net.Mail.Attachment –ArgumentList $report_path
	    $msg.Attachments.Add($attachment1) 
	  
	    $smtp.Send($msg)
	    $attachment.Dispose();
	    $msg.Dispose();

    }
    catch{
        Get-Wfalogger -Info -Message $($_ | out-string)
    }

}

#-------- Variables ----------

$wfa_job_id =  $(Get-WfaRestParameter "jobId")
$date_now = (Get-Date -Format 'dd-MM-yy_hh-mm-ss')

$report_path = "//dbg/lon-gto/netapp/WFA_Logs/secops_reports"
if(-Not(Test-Path  "$report_path")){

    Get-Wfalogger -Info -message "$report_path directory not present"
    Throw
}

$start_date = $date_range.Split('~')[0]
$end_date = $date_range.Split('~')[1]



########################################################################
# MAIN
########################################################################


Get-WfaLogger -Info -Message "##################### PRELIMINARIES #####################"
Get-WfaLogger -Info -Message "Get DB Passwords"
$playground_pass  = Get-WFAUserPassword -pw2get "WFAUSER"
$mysql_pass       = Get-WFAUserPassword -pw2get "MySQL"

$request = @{
   'request_type'             = $request_type.ToLower();
   'email'                    = $email;
   'environment'              = $environment.ToLower();
   'location'                 = $location.ToLower();
   'start_date'               = $start_date;
   'end_date'                 = $end_date;
  
}

if($environment -eq 'all'){
$budget_environment_filter = "(env = 'prd' OR env = 'uat' OR env = 'dev')"
$allocation_environment_filter = "(environment = 'prd' OR environment = 'uat' OR environment = 'dev')"}
else{
$budget_environment_filter = "(env = '$environment')"
$allocation_environment_filter = "(environment = '$environment')"
}

if($($request['location']) -eq 'all'){
$budget_location_filter = "(location = 'lon' OR location = 'fra' OR location = 'sin' OR location = 'nyc')"
$allocation_location_filter = "(vserver_name like 'lon%' OR vserver_name like 'fra%' OR vserver_name like 'sin%' OR vserver_name like 'nyc%')"}
else{
$budget_location_filter = "(location = '$($request['location'])')"
$allocation_location_filter = "(vserver_name like '$($request['location'])%')"
}


if($($request['request_type']) -eq 'Allocation'){
$report = allocation_report -request $request -db_user 'root' -db_pw $mysql_pass}
elseif ($($request['request_type']) -eq 'Budget'){
$report = budget_report -request $request -db_user 'root' -db_pw $mysql_pass}
$report = $report -replace("/","\")
Get-WfaLogger -Info -Message $report

send_email -message "Your SECOPS $($request['request_type']) is attached in the email" -report_path $report

