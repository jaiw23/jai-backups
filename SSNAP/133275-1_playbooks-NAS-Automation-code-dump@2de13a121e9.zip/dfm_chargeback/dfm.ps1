﻿$LogPath = "D:\dfm_chargeback\log" 
$LogTime = (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -replace (":","_") -replace("-","_")
$DfmLog = $LogPath + "\" + $LogTime+ "_dfm_update.txt"

# Start log 
Start-Transcript $DfmLog

Function Get-MySQLRootPW { 
   #Get the WFA http port
   $REGISTRY      = "HKLM:\SOFTWARE\Wow6432Node\Apache Software Foundation\Procrun 2.0\NA_WFA_SRV\Parameters\Java"
   $httpPort      = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dhttp.port"}).split("=")[1]
   $httpsPort     = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dhttps.port"}).split("=")[1]
   $sql_root_pw   = (Get-ItemProperty $REGISTRY |select -ExpandProperty Options|where {$_ -match "-Dmysql.password"}).split("=")[1]

   return $sql_root_pw;
}
 

Function MySQL {
    Param(
    [Parameter(
    Mandatory = $true,
    ParameterSetName = '',
    ValueFromPipeline = $true)]
    [string]$Query
    )
    $MySQLUser = "root"
    $Password = Get-MySQLRootPW
    $MySQLDB = "playground"
    $MySQLHost = "localhost"
    $ConnectionString = "server=" + $MySQLHost + ";port=3306;Integrated Security=False;uid=" + $MySQLUser + ";pwd=" + $Password + ";database="+$MySQLDB
    Try {
        [void][System.Reflection.Assembly]::LoadFrom('C:\Program Files (x86)\MySQL\MySQL Installer for Windows\MySql.Data.dll')
        $Connection = New-Object MySql.Data.MySqlClient.MySqlConnection
        $Connection.ConnectionString = $ConnectionString
        $Connection.Open()
              if ($Connection.State -ne "Open") {
                     Start-Sleep -Seconds 10
                     $Connection.Open()
              }
        $Command = New-Object MySql.Data.MySqlClient.MySqlCommand($Query, $Connection)
        $DataAdapter = New-Object MySql.Data.MySqlClient.MySqlDataAdapter($Command)
        $DataSet = New-Object System.Data.DataSet
        $RecordCount = $DataAdapter.Fill($DataSet, "data")
        $DataSet.Tables[0]
    }
    Catch {
        $Body = "Unable to process query $query" + "`r`n"
              $Body += "Please notify NetApp MSOS team with below error message" + "`r`n"
              $Body += "$Error[0]"
              #Emailer2 $Body
    }
    Finally {
        $Connection.Close()
    }
}

$DFMServer = "fradbstorxb1.de.db.com"
$DFMServerUsername = ""
$days = 1
$QueryChargeback = "SELECT * from playground.chargeback where timestamp >= now() - interval $days day ORDER BY timestamp ASC;"
#where timestamp > now() - interval 1 day
$Chargeback = MySQL -Query $QueryChargeback
#$Chargeback
$DFMPasswordPath = Get-Location
if(-Not(Test-Path  "$DFMPasswordPath\cred\credential.xml")) 
    { Get-Credential | Export-Clixml "$DFMPasswordPath\cred\credential.xml" }

$DFMServerCred = Import-Clixml $DFMPasswordPath\cred\credential.xml
#$QueryVol = "describe playground.chargeback limit 1;"
#$VolDetail = MySQL -Query $QueryVol
#$VolDetail | Format-Table

If($DFMServerCred.Length -eq 0){

    Write-Output "No Credentials found for the given Username ($DFMServerUsername) and Target (DFMServer) Combination"
    Exit
}

ElseIf($DFMServerCred.Length -gt 1){

    Write-Output "Multiple Credentials found for the given username - $DFMServerUsername"
    Exit
}

ForEach($item in $Chargeback)
    {
    Try{ 
        Invoke-Command -ComputerName $DFMServer -credential $DFMServerCred -ScriptBlock { 
         $item = $using:item
         $cmd = "DFM COMMENT SET $($item.vserver_name):/$($item.volume_name)/$($item.qtree_name) Application=`"$($item.app_short_name)`" ownerName=`"$($item.email_address)`" NAR=`"$($item.nar_id)`" Cost_Centre=`"$($item.cost_centre)`" Domain=`"$($item.nis_domain)`" Netgroup_RW=`"$($item.netgroup_rw)`" Netgroup_RO=`"$($item.netgroup_ro)`" ownerEmail=`"$($item.email_address)`" Service=`"$($item.service_name)`" RITM=`"$($item.ritm)`" ENV=`"$($item.environment)`" Creation=`"$($item.timestamp)`""
         $cmd
         Write-Output "`n"
         & cmd.exe /c $cmd
        } -ErrorAction Stop

    Write-Output "Data successfully updated `n"
    }
    
Catch{

        Write-Output "Failed to insert data to DFM .`nError: $($_.Exception.Message) (Line No. $($_.InvocationInfo.ScriptLineNumber))`n" -ForegroundColor Red

    } 
       

    }

# End temp log
Stop-Transcript

############send mail#######################
$mailbody = "DFM chargeback update report for $(Get-Date -Format "dd-MM-yyyy")"
$fromaddress = "netapp@nycinnwfab1.us.db.com" 
$toaddress =  @('bryce-a.martin@db.com', 'jai.waghela@db.com')
$attachment = $DfmLog
#$toaddress =  @('jai.waghela@db.com')
$body = $mailbody
$Subject = "DFM update report- $(Get-Date -Format "dd-MM-yyyy")"
$SMTPServer = "smtphub.na.mail.db.com"
Send-MailMessage -From $fromaddress -to $toaddress  -Subject $Subject `
-Body $body -BodyAsHtml -SmtpServer $SMTPServer -Attachments $attachment
####################
