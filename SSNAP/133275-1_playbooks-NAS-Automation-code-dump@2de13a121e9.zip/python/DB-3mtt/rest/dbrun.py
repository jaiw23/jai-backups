import requests
import urllib3
import json
import time
import argparse
import sys
import json
from datetime import datetime, date,  timedelta
from time import sleep
import yaml
import re
import pdb
from snow import snow

class dbrun(object):
   def __init__(self, db_cfg):
      self.cfg = db_cfg['dbrun']
      self.snow_cfg = db_cfg['snow']
      self.token = ''
      self.reason = 'Error While Executing DB Run'
      self.success   = False
      self.headers = {
         "accept":      "application/json",
      }
   
   def get_auth_token(self): 
      try:
         url = self.cfg['base_url'] + '/auth/system_tokens/'+self.cfg['nar_id']+'/'+self.cfg['env']
         response = requests.get(url=url, verify=False)
         if response.status_code == 200:
            response_dict = json.loads(response.text)
            self.token = response_dict[0]['token']
            expiry = response_dict[0]['expires']
            if expiry <=self.cfg['grace_period']:
               url = self.cfg['base_url'] + '/auth/refresh_system_tokens'
               self.headers.update({ "X-Auth-Token": self.token, "content-type": "application/json"})
               data = {
                  "env":         self.cfg['env'],
                  "nar":         self.cfg['nar_id'],
               }
               response = requests.post(url=url,  headers=self.headers, verify=False, data=data)
               if response.status_code != 200:
                  raise(Exception(response.json()))
         else:
            raise(Exception(response.json()))
      except Exception as e:
         raise(Exception(str(e)))

   def wfa(self, vars, data_var_regex = "raw_req_[0-9]+", match_str = "__res_type=[a-z0-9]+"):
      try:
         var_names = []
         for var_name in vars.keys():
            if re.match(data_var_regex, var_name):
               var_names.append(var_name)
         var_names.sort()
         raw_service_request = dict(req_details=dict())
         for var_name in var_names:
            if re.match(match_str, vars[var_name]):
               data = vars[var_name].split(';')
               res_type = data[0].split('=')[1]
               if not res_type in raw_service_request['req_details']:
                  raw_service_request['req_details'][res_type] = []
               tmp = dict(attr.split('=') for attr in data[1].split(','))
               raw_service_request['req_details'][res_type].append(tmp)
            else:
               attr = vars[var_name].split(';')[1].split('=')[0]
               val = vars[var_name].split(';')[1].split('=')[1]
               raw_service_request[attr] = val
         return raw_service_request
      except Exception as e:
         raise(Exception(str(e)))

    # Take the bulk_prov request from the REST API and convert it
    # to a raw_service_request
   def bulk_prov(self, request):
      raw_service_request = {
         'service':              'nas_shared_vfs',
         'operation':            'create',
         'std_name':             'NONE',
         'req_details': {}
      }
      ontap_resources = request.keys()
      for ontap_res in ontap_resources:
         if ontap_res != "servicenow":
            ms_name = 'ontap_' + ontap_res
         else:
            ms_name = ontap_res
         raw_service_request['req_details'].update(
            {
               ms_name: request[ontap_res]
            }
         )

      # Volume autosize attributes are included in the volume attrs.
      
      if 'volume' in ontap_resources:
         auto_size_attrs = set(
            [
               'grow_threshold_percent',
               'increment_size',
               'maximum_size',
               'minimum_size',
               'mode',
               'shrink_threshold_percent'
            ]
         )
         for volume in raw_service_request['req_details']['ontap_volume']:
            vol_attrs = set(volume.keys())
            vol_autosize_attrs = auto_size_attrs & vol_attrs
            if len(vol_autosize_attrs) == 0:
               continue
            if not 'ontap_volume_autosize' in raw_service_request['req_details']:
               raw_service_request['req_details'].update( { 'ontap_volume_autosize': [] } )

            tmp_autosize = {}
            for vol_autosize_attr in vol_autosize_attrs:
               tmp_autosize.update( {vol_autosize_attr: volume[vol_autosize_attr]} )
               del volume[vol_autosize_attr]
               
            tmp_autosize.update( 
               { 
                  'hostname': volume['hostname'],
                  'vserver':  volume['vserver'],
                  'volume':   volume['name']
               }
            )
            print(tmp_autosize)
            raw_service_request['req_details']['ontap_volume_autosize'].append(tmp_autosize)
            print(raw_service_request['req_details']['ontap_volume_autosize'])

      return raw_service_request

   def get_request(self, db_run_params):
      print("get_request")
      #return { "something": "result" }
      try:
         print(str(self.cfg))
         #self.get_auth_token()
         url = self.cfg['base_url'] + '/executor/results/' + self.cfg['nar_id'] + '/' + str(db_run_params['audit_id'])
         self.headers.update({ "X-Auth-Token": self.token, "content-type": "application/json"})
         response = requests.get(url=url,  headers=self.headers, verify=False)
         if response.status_code == 200:
            response_dict = json.loads(response.text)
            self.success = True
            print(response.json())
            return response.json()
         else:
            raise(Exception(response.json()))      
      except Exception as e:
         raise(Exception(str(e)))

   def post_request(self, db_run_params):
      # return {
      #    "audit_id": 212729,
      #    "status": "Action Queued Successfully!!"
      # }

      try:

          # Code to add the serviceNow access tokens for anisble
      
         snow_srvr = snow(self.snow_cfg, db_run_params) 
         snow_srvr.get_auth_token()
         snow_srvr.tag_correlation_id()
         if 'servicenow' in db_run_params['req_details']:
            for i in range(len(db_run_params['req_details']['servicenow'])):
               db_run_params['req_details']['servicenow'][i].update({'access_token': snow_srvr.snow_general_headers['Authorization']})



         url = self.cfg['base_url'] + '/executor/executions'
         data = {
            "env" :          self.cfg['env'],
            "action":        self.cfg['action'],
            "component":     self.cfg['component'],
            "continue_with_allowed_servers":      self.cfg['continue_with_allowed_servers'],
            "narId":         self.cfg['nar_id'],
            "impacted_nar":  self.cfg['nar_id'],
            "description":   self.cfg['description'],
            "queued":        self.cfg['queued'],
            "user":          self.cfg['user'],
            "force_continue":self.cfg['force_continue'],
            "instance":      self.cfg['instance'],
            "param":         [{"name":"raw_service_request", "type":"dictionary", "value":db_run_params}],
            "snow_id":       "",
            "text_output":   self.cfg['text_output'],
         }
         data = json.dumps(data)
         self.headers.update({ "X-Auth-Token": self.token, "content-type": "application/json"})
         response = requests.post(url=url,  headers=self.headers, verify=False, data=data)   
         if response.status_code == 200:
            response_dict = json.loads(response.text)
            self.success = True
            return response_dict['audit_id']
         else:
            raise(Exception(response.json()))
      except Exception as e:
         raise(Exception(str(e)))
