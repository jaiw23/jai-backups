import requests
import urllib3
import json
import time
import argparse
import sys
import json
from datetime import datetime, date,  timedelta
from time import sleep
import yaml
import re
import pdb

class snow(object):

   def __init__(self, snow_cfg, db_run_params):
      self.api = snow_cfg
      if 'servicenow' in db_run_params['req_details']:            
         self.api['correlation_id'] = db_run_params['req_details']['servicenow'][0]['correlation_id']
         self.api['sys_id'] = db_run_params['req_details']['servicenow'][0]['sys_id']
      self.proxies = {
        'https':  'http://serverproxy.intranet.db.com:8080'
      }
      self.snow_general_headers = {
         "Content-Type":      "application/json",
         "Accept":            "application/json",   
         "Authorization":     "Bearer " 
      }
      self.snow_auth_headers = {
          "Content-Type":"application/x-www-form-urlencoded",
      }

   def get_auth_token(self):
      try:
         payload = "client_id="+ self.api['client_id'] +"&client_secret="+ self.api['client_secret']
         set_days = int(self.api['days'])
         if self.api['refresh_token'] != "" and self.api['refresh_token_timestamp'] + timedelta(days=set_days) >= datetime.today():
            payload = payload + "&grant_type=refresh_token&refresh_token="+self.api['refresh_token']
         else:
            payload = payload + "&grant_type=password&username="+ self.api['user'] +"&password="+self.api['pw']
         url = self.api['base_url'] + '/oauth_token.do'
         response = requests.post(url, data=payload,  headers=self.snow_auth_headers, proxies = self.proxies, verify=False)
         if response.status_code == 200:
            response_dict = json.loads(response.text)
            self.snow_general_headers['Authorization'] = self.snow_general_headers['Authorization'] + response_dict["access_token"]
            if self.api['refresh_token'] == "" or self.api['refresh_token'] != response_dict["refresh_token"]:  
               with open('snow-interface.cfg', 'r') as yamlfile:
                  cur_yaml = yaml.safe_load(yamlfile)          
                  cur_yaml['snow']['refresh_token'] = response_dict["refresh_token"]
                  cur_yaml['snow']['refresh_token_timestamp'] = datetime.today()
               with open('snow-interface.cfg', 'w') as yamlfile:
                  yaml.safe_dump(cur_yaml, yamlfile)
         else:
            raise(Exception(response.json()))
      except Exception as e:
         raise(Exception(str(e)))

  
   def add_snow_worknotes(self, comment):
      try:   
         url = self.api['base_url'] + '/api/global/v1/srm_task_api/task/update_actions'

         data = {
            'action': "comment",
            'correlation_id': self.api['correlation_id'] ,
            'sys_id': self.api['sys_id'],
            'work_notes': comment,
            }
         response = requests.post(url,headers=self.snow_general_headers,json=data, proxies = self.proxies)
         if response.status_code != 200:
            raise(Exception(response.json()))
      except Exception as e:
         raise(Exception(str(e)))

   def set_req_status(self, status, cancel_reason="",comments=""):
      try:
         url = self.api['base_url'] + '/api/global/v1/srm_task_api/task/update_actions'
         
         data = {
            'action': status,
            'correlation_id': self.api['correlation_id'] ,
            'sys_id': self.api['sys_id'],
            }

         if cancel_reason != "":
            data['u_cancellation_reason'] = cancel_reason

         if comments != "":
            data['comments'] = comments

         response = requests.post(url, headers=self.snow_general_headers, json=data, proxies = self.proxies)
      
         if response.status_code != 200:
            raise(Exception(response.json()))
      except Exception as e:
         raise(Exception(str(e)))

   def get_req(self, snow_req_number):
      response = requests.get(self.api['base_url'] + '/api/now/table/sc_request?sysparm_query=number%3D' + snow_req_number + '&sysparm_display_value=true', 
         headers=self.snow_general_headers, proxies = self.proxies
      )
      if response.status_code == 200:
         return response.json()
      else:
         raise(Exception(response.json()))

   def tag_correlation_id(self):
      try:   
         url = self.api['base_correlation_url'] + '/api/global/v1/srm_task_api/task/update_actions'

         data = {
            'action': "correlation",
            'correlation_id': self.api['correlation_id'] ,
            'sys_id': self.api['sys_id'],
            }
         response = requests.post(url,headers=self.snow_general_headers,json=data, proxies = self.proxies)
         if response.status_code != 200:
            raise(Exception(response.json()))
      except Exception as e:
         #raise(Exception(str(e)))
         pass

