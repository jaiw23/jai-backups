#!/usr/bin/env python
import os
import time
from flask import Flask, abort, request, jsonify, g, url_for, Response
from flask_restful import reqparse, abort, Api, Resource, fields
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
from flask_jwt_extended import jwt_required, JWTManager, create_access_token, get_jwt_identity
import datetime


from werkzeug.security import generate_password_hash, check_password_hash

# initialization
app = Flask(__name__)
app.config['SECRET_KEY'] = 'the quick brown fox jumps over the lazy dog'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/3mtt/rest/db.sqlite'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['JWT_SECRET_KEY'] = 't1NP63m4wnBg6nyHYKfmc2TpCOGI4nss'

api = Api(app)
# extensions
db      = SQLAlchemy(app)
auth    = HTTPBasicAuth()
bcrypt  = Bcrypt(app)
jwt = JWTManager(app)

class User(db.Model):
    __tablename__ = 'users'
    id              = db.Column(db.Integer, primary_key=True)
    username        = db.Column(db.String(32), index=True)
    password_hash   = db.Column(db.String(128))

    def hash_password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

class SignupApi(Resource):
    def post(self):
        username = request.json.get('username')
        password = request.json.get('password')
        user = User(username = username)
        user.hash_password(password)
        db.session.add(user)
        db.session.commit()
        return { "username": username }, 201

class LogIn(Resource):
    def post(self):
        body = request.get_json()
        username = request.json.get('username')
        password = request.json.get('password')
        if not is_authorized(username, password):
            return { 'error': 'username or password invalid' }, 401
        access_token = create_access_token(identity=username)
        return { 'token': access_token }, 200


def is_authorized(username, password):
    user = User.query.filter_by(username=username).first()
    g.user = user
    authorized = user.verify_password(password)
    return authorized

api.add_resource(SignupApi, '/api/auth/signup')
api.add_resource(LogIn,     '/api/auth/token')

if __name__ == '__main__':
    if not os.path.exists('/home/3mtt/rest/db.sqlite'):
        db.create_all()
    app.run(debug=True)
