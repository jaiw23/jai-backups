from flask import Flask, abort, request, jsonify, g, url_for, Response
from flask_restful import reqparse, abort, Api, Resource, fields
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
from flask_jwt_extended import jwt_required, JWTManager, create_access_token, get_jwt_identity
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
import os
import time
import datetime

from dbrun import dbrun
from snow import snow

import json

import urllib3
import argparse
import yaml
import os

# import PyYAML
import pdb

app = Flask(__name__)
auth = HTTPBasicAuth()

api = Api(app)

app.config['SECRET_KEY'] = 'the quick brown fox jumps over the lazy dog'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['JWT_SECRET_KEY'] = 't1NP63m4wnBg6nyHYKfmc2TpCOGI4nss'

db = SQLAlchemy(app)
auth = HTTPBasicAuth()
bcrypt  = Bcrypt(app)
jwt = JWTManager(app)
class User(db.Model):
    __tablename__ = 'users'
    id              = db.Column(db.Integer, primary_key=True)
    username        = db.Column(db.String(32), index=True)
    password_hash   = db.Column(db.String(128))

    def hash_password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)


class LogIn(Resource):
    def post(self):
        body = request.get_json()
        username = request.json.get('username')
        password = request.json.get('password')
        if not is_authorized(username, password):
            return { 'error': 'username or password invalid' }, 401
        access_token = create_access_token(identity=username)
        return { 'token': access_token }, 200

def is_authorized(username, password):
    user = User.query.filter_by(username=username).first()
    g.user = user
    authorized = user.verify_password(password)
    return authorized

################################################################
# SVM BUILD API - NAS Provisioning
################################################################
# svm_reqd_keys = {
#   'vserver':      set(),
#   'failover_grp': set(),
#   'mgmt_lif':     set(),
#   'dns':          set(),
#   'cifs_server':  set(),
#   'nfsv3':        set(),
#   'nis_domain':   set()
# }

def svm_post_data_is_valid( bld_req ):
  result =  { "is_valid": 1, "reason": "Request is valid", "request": bld_req } 
  return result

class svm_build(Resource):
  #@jwt_required()
  def post(self):
    post_parser = reqparse.RequestParser()
    svm_build_type = reqparse.Argument(
      'raw_service_request',
      required=True,
      type=svm_post_data_is_valid
    )
    post_parser.add_argument(svm_build_type)
    build_request = post_parser.parse_args()['raw_service_request']
    if build_request['is_valid']:
      f = open('/home/3mtt/rest/payload_logs/svm_build.log', 'w')
      f.write(json.dumps(build_request) + "\n")
      f.close()
      result = db_run_obj.post_request(build_request['request'])
      return result, 201      
    else:
      return { 'success': 0, 'error': build_request['validation']['reason'] }, 400

################################################################
# CLUSTER BUILD API - NAS Provisioning
################################################################

# def bldreq2snowreq(build_request, snow_cfg):
#   snow_request = {
#     'sys_id':         build_request['snow']['sys_id'],
#     'number':         build_request['snow']['correlation_id'],
#     'url':            snow_cfg['ur'],
#     'raw_service_request': {
#       'service':    'cluster build',
#       'operation':  'create',
#       'std_name':   'none',
#       'req_details': build_request['cluster']
#     }
#   }
#   return snow_request

# # Everything except license is a dict
# cb_reqd_keys = {
#     'cluster': 
#       set(
#       [
#         'license',          # , separated list
#         'net_port',
#         'lif',
#         'bcast_domain',
#         'interface_grp',
#         'ipspace',
#         'peer_cluster',
#         'auto_support',
#         'ntp',
#         'smtp',
#         'dns'
#       ]
#     ),
#     'snow':
#       set(
#         [
#           'sys_id',
#           'correlation_id'
#         ]
#     )
# }

# def cb_license_is_valid(license):
#   return True

# def cb_bld_req_is_valid(bld_req):
#   return bld_req.update(
#     {
#       'validation': 
#       {
#         'is_valid': 1,
#         'reason':   'Request is valid'
#       }
#     }
#   )

# def cb_cluster_is_valid(bld_req):
#   return bld_req.update(
#     {
#       'validation': 
#       {
#         'is_valid': 1,
#         'reason':   'Request is valid'
#       }
#     }
#   )

def cb_post_data_is_valid(bld_req):
  result =  { "is_valid": 1, "reason": "Request is valid", "request": bld_req } 
  return result

class cluster_build(Resource):
  #@jwt_required()
  def post(self):
    post_parser = reqparse.RequestParser()
    cluster_build_type = reqparse.Argument(
      'raw_service_request',
      required=True,
      type=cb_post_data_is_valid
    )
    post_parser.add_argument(cluster_build_type)
    build_request = post_parser.parse_args()
    # pdb.set_trace()
    print(json.dumps(build_request))
    build_request = build_request['raw_service_request']
    if build_request['is_valid']:
      f = open('/home/3mtt/rest/payload_logs/cluster_build.log', 'w')
      f.write(json.dumps(build_request) + "\n")
      f.close()
      result = db_run_obj.post_request(build_request['request'])
      return result, 201      
    else:
      return { 'success': 0, 'error': build_request['validation']['reason'] }, 401

################################################################
# 3 MTT API - bulk provisioning
################################################################
def post_data_is_valid(bulk_req):
  # reqd_keys = set(['volume','qtree','quotas','servicenow'])
  # diff = reqd_keys - set(bulk_req['request'].keys())
  # if len(diff) != 0:
  #   result = { "is_valid": 0, "reason": "Missing the following required parameters: " + ",".join(diff)}
  #   return result

  result =  { "is_valid": 1, "reason": "Request is valid", "request": bulk_req } 
  return result


class three_mtt(Resource):
  # Get status of DB Run job
  @jwt_required()
  def get(self):
    get_parser = reqparse.RequestParser()
    get_parser.add_argument('audit_id',
      required=True,
      type=int,
    )
    args = get_parser.parse_args()
    # db_run_obj = dbrun ( {} )
    result = db_run_obj.get_request(args)
    return result

  @jwt_required()
  def post(self):
    post_parser = reqparse.RequestParser()
    share_type = reqparse.Argument('request',
      required=True, 
      type=post_data_is_valid
    )
    post_parser.add_argument(share_type)
    result = post_parser.parse_args()

    if not result.request['is_valid']:
      return result, 201

    raw_service_request = db_run_obj.bulk_prov(result.request['request'])
    db_result = db_run_obj.post_request( raw_service_request )
    return_value = { "db_run": db_result } 
    #return_value = {}
    return_value.update( { "raw_service_request": raw_service_request } )

    return return_value, 201

#---------------------------------------------------------------
# These steps are required all the time
#---------------------------------------------------------------
reqd_keys = {
  'volume': set(
    [
      'hostname',
      'vserver',
      'volume',
      'aggregate',
      'policy',
      'type',
      'snapshot-policy',
      # 'max-autosize',
      # 'autosize-mode', #not supported by ontap_volume
      'junction-path',
      'space-guarantee',
      'qos-adaptive-policy-group',
      'percent-snapshot-space',
      'share-type'
    ]
  ),
  'qtree': set (
    [
      'hostname',
      'vserver',
      'volume',
      'qtree-name',
      'security-style',
      'export-policy',
      'disk-limit'
    ]
  ),
  'cifs': set (
    [
      'share_name',
      'hostname',
      'vserver',
      'path'
    ]
  )
}


api.add_resource(three_mtt,     '/api/v1/3mtt')
api.add_resource(cluster_build, '/api/v1/nas_provisioning/cluster')
api.add_resource(svm_build,     '/api/v1/nas_provisioning/svm')
api.add_resource(LogIn,         '/api/auth/token')

urllib3.disable_warnings (urllib3.exceptions.InsecureRequestWarning)
parser = argparse.ArgumentParser()
parser.add_argument('-c', '--cfg-file',      required=False,   default='snow-interface.cfg')
args, unknown = parser.parse_known_args()
try:
  with open(args.cfg_file) as cfg_file:
      cfg = yaml.safe_load(cfg_file)
except FileNotFoundError:
  msg = "Cfg file not found: " + args.cfg_file
  raise Exception(msg)

db_run_obj = dbrun( cfg )
db_run_obj.get_auth_token()
#---------------------------------------------------------------
# Only when we want to run the included web server for testing
#---------------------------------------------------------------
if __name__ == '__main__':
  app.run(debug=True,port=5001,host='0.0.0.0')
