from user_mgmt import app

if __name__ == "__main__":
  app.run()
